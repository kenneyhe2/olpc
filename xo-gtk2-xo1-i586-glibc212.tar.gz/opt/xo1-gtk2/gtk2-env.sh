#!/bin/sh
HERE="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
export LD_LIBRARY_PATH="${HERE}/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export GDK_PIXBUF_MODULEDIR="${HERE}/lib/gdk-pixbuf-2.0/2.10.0/loaders"
export GTK_PATH="${HERE}/lib/gtk-2.0"
