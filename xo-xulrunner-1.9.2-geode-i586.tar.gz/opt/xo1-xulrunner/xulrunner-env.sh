#!/bin/sh
HERE="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
XR=$(ls -d "$HERE"/lib/xulrunner-* 2>/dev/null | head -1)
[ -n "$XR" ] || XR="$HERE/lib"
export MOZILLA_FIVE_HOME="$XR"
export LD_LIBRARY_PATH="$XR:$HERE/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
